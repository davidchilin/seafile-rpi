import React from 'react';

function Loading() {
  return (
    <span className="loading-icon loading-tip"></span>
  );
}

export default Loading;