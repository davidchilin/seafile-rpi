'use strict';

require('react-app-polyfill/ie9');
require('react-app-polyfill/stable');
